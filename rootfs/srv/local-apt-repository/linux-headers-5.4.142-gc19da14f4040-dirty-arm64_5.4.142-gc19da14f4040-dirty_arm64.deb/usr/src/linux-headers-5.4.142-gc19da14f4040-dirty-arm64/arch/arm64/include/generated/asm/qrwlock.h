#include <asm-generic/qrwlock.h>
