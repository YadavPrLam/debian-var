/* This file is auto generated, version 2 */
/* SMP PREEMPT */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#2 SMP PREEMPT Fri Mar 24 15:33:41 PDT 2023"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "offboard-NUC7i7DNB"
#define LINUX_COMPILER "gcc version 6.3.1 20170404 (Linaro GCC 6.3-2017.05)"
